<!DOCTYPE html>
<html>
<body>


<p>We Need your Location Details to proceed further.</p>

<button onclick="getLocation()">Allow Location</button>

<script>
var x = document.getElementById("demo");

function getLocation() {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(redirectToPosition);
    } else { 
        x.innerHTML = "Geolocation is not supported by this browser.";
    }
}

function redirectToPosition(position) {
    window.location="message2.php?lat='+position.coords.latitude+'&long='+position.coords.longitude";
}
</script>

</body>
</html>
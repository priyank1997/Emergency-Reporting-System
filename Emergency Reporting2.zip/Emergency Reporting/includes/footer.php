<footer>
    <div class="container">
        <center>
            <p>Copyright &copy; <a target="_blank" href="http://meetshah.tech">Meet Shah</a>. All Rights Reserved | Contact Us: <a  href="tel:9033477202">+91 9033477202</a></p>
        </center>
    </div>
</footer>